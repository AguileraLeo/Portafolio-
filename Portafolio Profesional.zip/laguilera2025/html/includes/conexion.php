<?php
$host = "localhost";
$usuario = "laguilera";
$password = "laguilera2026";
$base_datos = "laguilera_db1";

$conexion = new mysqli($host, $usuario, $password, $base_datos);

if ($conexion->connect_error) {
    die("Error de conexión: " . $conexion->connect_error);
}

$conexion->set_charset("utf8");
?>